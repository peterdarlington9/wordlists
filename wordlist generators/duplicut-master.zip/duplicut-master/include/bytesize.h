#pragma once

long long   bytesize(const char *str);
char        *sizerepr(size_t size);
