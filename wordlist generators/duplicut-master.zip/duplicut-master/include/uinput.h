#pragma once

/* source file: user_input.c */
void        watch_user_input(void);
