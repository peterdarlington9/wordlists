#pragma once

/* source file: tag_duplicates.c */
void     tag_duplicates(void);
